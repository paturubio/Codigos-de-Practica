
package mezclasdepinturas;
import java.util.Scanner;

public class MezclasdePinturas {

    public static void main(String[] args) {
     System.out.println("Programa de mescla"
             + " de colores");
     System.out.println("Seleccione el tono que "
             + " le gustaria mesclar");
     System.out.println("R = Rojo");
     System.out.println("A = Azul");
     System.out.println("V = Verde");
     Scanner leer = new Scanner(System.in);
     String color = leer.nextLine();
//Para rojo
     if (color.equals("R")|| color.equals("r")){
    System.out.println("Con que tono le gustaria mesclar :");
    System.out.println("A = Azul");
    System.out.println("V = Verde");
    String tonosrojos = leer.nextLine();
    if(tonosrojos.equals("A")||tonosrojos.equals("a")){
    System.out.println("Su mescla es Rojo con Azul");
    System.out.println("Su color obtenido es Morado");
    }
    if(tonosrojos.equals("V")|| tonosrojos.equals("v")){
    System.out.println("Su mescla es Rojo con Verde");
    System.out.println("Su color obtenido es Cafe");
    }
     }//Para azul
     if (color.equals("A")|| color.equals("a")){
    System.out.println("Con que tono le gustaria mesclar :");
    System.out.println("R = Rojo");
    System.out.println("V = Verde");
    String tonosazules = leer.nextLine();
    if(tonosazules.equals("R")||tonosazules.equals("r")){
    System.out.println("Su mescla es Azul con Rojo");
    System.out.println("Su color obtenido es Morado");
    }
    if(tonosazules.equals("V")||tonosazules.equals("v")){
    System.out.println("Su mescla es Azul con Verde");
    System.out.println("Su color obtenido es Celeste");
    }
     }//Para verde
     if (color.equals("V")|| color.equals("v")){
    System.out.println("Con que tono le gustaria mesclar :");
    System.out.println("A = Azul");
    System.out.println("R = Rojo");
    String tonosverdes = leer.nextLine();
    if(tonosverdes.equals("A")||tonosverdes.equals("a")){
    System.out.println("Su mescla es Verde con Azul");
    System.out.println("Su color obtenido es Celeste");
    }
    if(tonosverdes.equals("V")||tonosverdes.equals("v")){
    System.out.println("Su mescla es Verde con Rojo");
    System.out.println("Su color obtenido es Cafe");
    }
    }  
    }
    }
//JOption.Pane.showMessageDialog( , );
