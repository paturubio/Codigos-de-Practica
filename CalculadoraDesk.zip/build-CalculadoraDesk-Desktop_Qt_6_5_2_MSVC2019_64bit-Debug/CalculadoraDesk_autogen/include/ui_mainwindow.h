/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QFormLayout *formLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QDoubleSpinBox *x1;
    QLabel *label_3;
    QDoubleSpinBox *x2;
    QFormLayout *formLayout;
    QPushButton *suma;
    QPushButton *resta;
    QPushButton *multiplicacion;
    QPushButton *division;
    QPushButton *porcentaje;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QLabel *label_4;
    QLabel *resp;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->setWindowModality(Qt::NonModal);
        MainWindow->resize(549, 263);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../Downloads/502d2e2f-f6cd-4508-9707-03c7663ecc1e.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("border-color: rgb(0, 0, 0);\n"
"color: rgb(0, 0, 0);\n"
"background-color: rgb(126, 126, 126);\n"
"\n"
"\n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(20, 50, 508, 161));
        formLayout_2 = new QFormLayout(layoutWidget);
        formLayout_2->setObjectName("formLayout_2");
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName("label_2");
        label_2->setFrameShape(QFrame::NoFrame);

        horizontalLayout_2->addWidget(label_2);

        x1 = new QDoubleSpinBox(layoutWidget);
        x1->setObjectName("x1");
        x1->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(170, 170, 255);\n"
"border-color: rgb(255, 255, 255);"));
        x1->setMinimum(-9999999999.000000000000000);
        x1->setMaximum(999999999.000000000000000);

        horizontalLayout_2->addWidget(x1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName("label_3");

        horizontalLayout_2->addWidget(label_3);

        x2 = new QDoubleSpinBox(layoutWidget);
        x2->setObjectName("x2");
        x2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(170, 170, 255);\n"
"border-color: rgb(255, 255, 255);"));
        x2->setMinimum(-9999999999.000000000000000);
        x2->setMaximum(999999999.000000000000000);

        horizontalLayout_2->addWidget(x2);


        formLayout_2->setLayout(0, QFormLayout::LabelRole, horizontalLayout_2);

        formLayout = new QFormLayout();
        formLayout->setObjectName("formLayout");
        suma = new QPushButton(layoutWidget);
        suma->setObjectName("suma");
        suma->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(183, 211, 255);\n"
"border-color: rgb(97, 96, 95);"));

        formLayout->setWidget(0, QFormLayout::LabelRole, suma);

        resta = new QPushButton(layoutWidget);
        resta->setObjectName("resta");
        resta->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(183, 211, 255);\n"
"border-color: rgb(97, 96, 95);"));

        formLayout->setWidget(0, QFormLayout::FieldRole, resta);

        multiplicacion = new QPushButton(layoutWidget);
        multiplicacion->setObjectName("multiplicacion");
        multiplicacion->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(183, 211, 255);\n"
"border-color: rgb(97, 96, 95);"));

        formLayout->setWidget(1, QFormLayout::LabelRole, multiplicacion);

        division = new QPushButton(layoutWidget);
        division->setObjectName("division");
        division->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(183, 211, 255);\n"
"border-color: rgb(97, 96, 95);"));

        formLayout->setWidget(1, QFormLayout::FieldRole, division);

        porcentaje = new QPushButton(layoutWidget);
        porcentaje->setObjectName("porcentaje");
        porcentaje->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(183, 211, 255);\n"
"border-color: rgb(97, 96, 95);"));

        formLayout->setWidget(2, QFormLayout::SpanningRole, porcentaje);


        formLayout_2->setLayout(0, QFormLayout::FieldRole, formLayout);

        label = new QLabel(layoutWidget);
        label->setObjectName("label");

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName("label_4");
        label_4->setAutoFillBackground(false);

        horizontalLayout->addWidget(label_4);

        resp = new QLabel(layoutWidget);
        resp->setObjectName("resp");

        horizontalLayout->addWidget(resp);


        formLayout_2->setLayout(2, QFormLayout::FieldRole, horizontalLayout);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
#if QT_CONFIG(whatsthis)
        MainWindow->setWhatsThis(QCoreApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        label_2->setText(QCoreApplication::translate("MainWindow", "Num 1", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Num 2", nullptr));
        suma->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        resta->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        multiplicacion->setText(QCoreApplication::translate("MainWindow", "*", nullptr));
        division->setText(QCoreApplication::translate("MainWindow", "/", nullptr));
        porcentaje->setText(QCoreApplication::translate("MainWindow", "%", nullptr));
        label->setText(QString());
        label_4->setText(QCoreApplication::translate("MainWindow", "RESP: ", nullptr));
        resp->setText(QCoreApplication::translate("MainWindow", "...........", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
