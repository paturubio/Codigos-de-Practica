#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Calculadora Aritmetica Basica");
    ui-> resp -> setText("");

}


void MainWindow::on_suma_clicked()
{
    ui-> resp -> setText(QString:: number(ui->x1-> value()+ ui-> x2->value()));
}


void MainWindow::on_resta_clicked()
{
    ui-> resp -> setText(QString:: number(ui->x1-> value()- ui-> x2->value()));
}


void MainWindow::on_multiplicacion_clicked()
{
    ui-> resp -> setText(QString:: number(ui->x1-> value()* ui-> x2->value()));
}


void MainWindow::on_division_clicked()
{
    ui-> resp -> setText(QString:: number(ui->x1-> value()/ ui-> x2->value()));
}


void MainWindow::on_porcentaje_clicked()
{
    ui-> resp -> setText(QString:: number(ui->x1-> value()* ui-> x2->value()/100));
}
MainWindow::~MainWindow()
{
    delete ui;
}

