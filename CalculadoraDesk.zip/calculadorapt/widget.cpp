#include "widget.h"
#include "./ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("Calculadora Aritmetica Basica");
    ui-> resp -> setText("");

}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_suma_clicked()
{
    ui-> resp -> setText(QString:: number(ui->x1-> value()+ ui-> x2->value()));
}


void Widget::on_resta_clicked()
{
ui-> resp -> setText(QString:: number(ui->x1-> value()- ui-> x2->value()));
}


void Widget::on_multiplicacion_clicked()
{
ui-> resp -> setText(QString:: number(ui->x1-> value()* ui-> x2->value()));
}


void Widget::on_division_clicked()
{
ui-> resp -> setText(QString:: number(ui->x1-> value()/ ui-> x2->value()));
}


void Widget::on_porcentaje_clicked()
{
ui-> resp -> setText(QString:: number(ui->x1-> value()* ui-> x2->value()/100));
}

