/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.5.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *layoutWidget;
    QFormLayout *formLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QDoubleSpinBox *x1;
    QLabel *label_3;
    QDoubleSpinBox *x2;
    QFormLayout *formLayout;
    QPushButton *suma;
    QPushButton *resta;
    QPushButton *multiplicacion;
    QPushButton *division;
    QPushButton *porcentaje;
    QHBoxLayout *horizontalLayout;
    QLabel *label_4;
    QLabel *resp;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(574, 240);
        layoutWidget = new QWidget(Widget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(40, 20, 482, 161));
        formLayout_2 = new QFormLayout(layoutWidget);
        formLayout_2->setObjectName("formLayout_2");
        formLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName("label_2");

        horizontalLayout_2->addWidget(label_2);

        x1 = new QDoubleSpinBox(layoutWidget);
        x1->setObjectName("x1");
        x1->setMinimum(-9999999999.000000000000000);
        x1->setMaximum(999999999.000000000000000);

        horizontalLayout_2->addWidget(x1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName("label_3");

        horizontalLayout_2->addWidget(label_3);

        x2 = new QDoubleSpinBox(layoutWidget);
        x2->setObjectName("x2");
        x2->setMinimum(-9999999999.000000000000000);
        x2->setMaximum(999999999.000000000000000);

        horizontalLayout_2->addWidget(x2);


        formLayout_2->setLayout(0, QFormLayout::LabelRole, horizontalLayout_2);

        formLayout = new QFormLayout();
        formLayout->setObjectName("formLayout");
        suma = new QPushButton(layoutWidget);
        suma->setObjectName("suma");

        formLayout->setWidget(0, QFormLayout::LabelRole, suma);

        resta = new QPushButton(layoutWidget);
        resta->setObjectName("resta");

        formLayout->setWidget(0, QFormLayout::FieldRole, resta);

        multiplicacion = new QPushButton(layoutWidget);
        multiplicacion->setObjectName("multiplicacion");

        formLayout->setWidget(1, QFormLayout::LabelRole, multiplicacion);

        division = new QPushButton(layoutWidget);
        division->setObjectName("division");

        formLayout->setWidget(1, QFormLayout::FieldRole, division);

        porcentaje = new QPushButton(layoutWidget);
        porcentaje->setObjectName("porcentaje");

        formLayout->setWidget(2, QFormLayout::SpanningRole, porcentaje);


        formLayout_2->setLayout(0, QFormLayout::FieldRole, formLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName("label_4");

        horizontalLayout->addWidget(label_4);

        resp = new QLabel(layoutWidget);
        resp->setObjectName("resp");

        horizontalLayout->addWidget(resp);


        formLayout_2->setLayout(1, QFormLayout::FieldRole, horizontalLayout);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        label_2->setText(QCoreApplication::translate("Widget", "Num 1", nullptr));
        label_3->setText(QCoreApplication::translate("Widget", "Num 2", nullptr));
        suma->setText(QCoreApplication::translate("Widget", "+", nullptr));
        resta->setText(QCoreApplication::translate("Widget", "-", nullptr));
        multiplicacion->setText(QCoreApplication::translate("Widget", "*", nullptr));
        division->setText(QCoreApplication::translate("Widget", "/", nullptr));
        porcentaje->setText(QCoreApplication::translate("Widget", "%", nullptr));
        label_4->setText(QCoreApplication::translate("Widget", "RESP: ", nullptr));
        resp->setText(QCoreApplication::translate("Widget", "...........", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
